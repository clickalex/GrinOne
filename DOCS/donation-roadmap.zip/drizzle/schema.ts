import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// TODO: Add your tables here

/**
 * Donations table — stores all donation records
 */
export const donations = mysqlTable("donations", {
  id: int("id").autoincrement().primaryKey(),
  donorName: varchar("donorName", { length: 255 }).notNull(),
  donorEmail: varchar("donorEmail", { length: 320 }),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 10 }).default("USD").notNull(),
  paymentMethod: mysqlEnum("paymentMethod", ["card", "paypal", "crypto_btc", "crypto_eth", "crypto_usdt", "bank_transfer"]).notNull(),
  campaign: varchar("campaign", { length: 255 }).notNull(),
  donationType: mysqlEnum("donationType", ["one-time", "recurring", "monthly"]).notNull(),
  message: text("message"),
  isAnonymous: boolean("isAnonymous").default(false).notNull(),
  status: mysqlEnum("status", ["pending", "completed", "failed"]).default("pending").notNull(),
  transactionRef: varchar("transactionRef", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Donation = typeof donations.$inferSelect;
export type InsertDonation = typeof donations.$inferInsert;

/**
 * Donor messages table — public thank-you messages
 */
export const donorMessages = mysqlTable("donorMessages", {
  id: int("id").autoincrement().primaryKey(),
  donationId: int("donationId"),
  name: varchar("name", { length: 255 }),
  message: text("message").notNull(),
  campaign: varchar("campaign", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DonorMessage = typeof donorMessages.$inferSelect;
export type InsertDonorMessage = typeof donorMessages.$inferInsert;