"""Generate GrinOne favicon SVG and PNG."""
import subprocess

# Create SVG favicon
svg_content = '''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
  <defs>
    <linearGradient id="g" x1="8" y1="8" x2="56" y2="52" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#f77f00"/>
      <stop offset="100%" stop-color="#e63946"/>
    </linearGradient>
  </defs>
  <!-- Heart/smile shape -->
  <path d="M32 52C32 52 8 36 8 22C8 14 14 8 22 8C27 8 30 11 32 14C34 11 37 8 42 8C50 8 56 14 56 22C56 36 32 52 32 52Z" fill="url(#g)" stroke="url(#g)" stroke-width="1.5" stroke-linejoin="round" opacity="0.9"/>
  <!-- Inner smile arc -->
  <path d="M22 30C26 36 38 36 42 30" stroke="white" stroke-width="3" stroke-linecap="round" fill="none"/>
  <!-- Radiating dots -->
  <circle cx="20" cy="16" r="2" fill="#f77f00" opacity="0.8"/>
  <circle cx="32" cy="12" r="2.5" fill="#e63946" opacity="0.9"/>
  <circle cx="44" cy="16" r="2" fill="#f77f00" opacity="0.8"/>
</svg>'''

# Write SVG favicon
with open('/home/ubuntu/webdev-static-assets/grinone-favicon.svg', 'w') as f:
    f.write(svg_content)
print("SVG favicon created")

# Also write to public for direct reference
import shutil
shutil.copy('/home/ubuntu/webdev-static-assets/grinone-favicon.svg', '/home/ubuntu/donation-roadmap/client/public/favicon.svg')
print("Favicon copied to public directory")
