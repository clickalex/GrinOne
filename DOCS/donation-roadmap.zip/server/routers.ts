import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import {
  createDonation,
  createDonorMessage,
  getDonationStats,
  getRecentDonations,
  getRecentMessages,
} from "./db";

const donationSchema = z.object({
  donorName: z.string().min(1).max(255),
  donorEmail: z.string().email().optional().or(z.literal("")),
  amount: z.string().min(1),
  currency: z.string().default("USD"),
  paymentMethod: z.enum(["card", "paypal", "crypto_btc", "crypto_eth", "crypto_usdt", "bank_transfer"]),
  campaign: z.string().min(1).max(255),
  donationType: z.enum(["one-time", "recurring", "monthly"]),
  message: z.string().max(500).optional(),
  isAnonymous: z.boolean().default(false),
});

const donorMessageSchema = z.object({
  name: z.string().max(255).optional(),
  message: z.string().min(1).max(500),
  campaign: z.string().max(255).optional(),
  donationId: z.number().optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  donations: router({
    create: publicProcedure
      .input(donationSchema)
      .mutation(async ({ input }) => {
        // Generate a transaction reference
        const txnRef = `GRN-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
        const result = await createDonation({
          ...input,
          status: "completed",
          transactionRef: txnRef,
        });
        return { success: true, transactionRef: txnRef };
      }),
    list: publicProcedure
      .input(z.object({ limit: z.number().default(50) }).optional())
      .query(async ({ input }) => {
        return getRecentDonations(input?.limit ?? 50);
      }),
    stats: publicProcedure.query(async () => {
      return getDonationStats();
    }),
  }),

  messages: router({
    create: publicProcedure
      .input(donorMessageSchema)
      .mutation(async ({ input }) => {
        await createDonorMessage(input);
        return { success: true };
      }),
    list: publicProcedure
      .input(z.object({ limit: z.number().default(10) }).optional())
      .query(async ({ input }) => {
        return getRecentMessages(input?.limit ?? 10);
      }),
  }),
});

export type AppRouter = typeof appRouter;
